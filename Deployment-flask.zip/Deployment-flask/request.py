import requests

url = 'http://localhost:5000/predict_api'
r = requests.post(url,json={'month=1,dayofmonth=1,dep_time=517,dep_time=515,dep_delay=2,sched_arr_time=830,arr_time=819,'})

print(r.json())
