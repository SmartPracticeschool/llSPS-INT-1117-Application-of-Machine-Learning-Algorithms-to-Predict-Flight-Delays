# Importing the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import pickle

dataset = pd.read_csv('flightsdelay1.csv')

dataset['dep_time']=dataset['dep_time'].replace('NA',np.nan)
dataset['dep_time']=dataset['dep_time'].astype('float32')

dataset['dep_time'].fillna(dataset['dep_time'].mean(),inplace=True)

dataset['dep_delay']=dataset['dep_delay'].replace('NA',np.nan)
dataset['dep_delay']=dataset['dep_delay'].astype('float32')

dataset['dep_delay'].fillna(0,inplace=True)

dataset['arr_time']=dataset['arr_time'].replace('NA',np.nan)
dataset['arr_time']=dataset['arr_time'].astype('float32')

dataset['arr_time'].fillna(dataset['arr_time'].mean(),inplace=True)

dataset['arr_delay']=dataset['arr_delay'].replace('NA',np.nan)
dataset['arr_delay']=dataset['arr_delay'].astype('float32')

dataset['arr_delay'].fillna(0,inplace=True)

dataset.drop(['year','tailnum','hour','minute','time_hour','flight','air_time','distance','carrier','origin','dest'],axis=1,inplace=True)



x = dataset.iloc[:, :7]


y = dataset.iloc[:, -1]
from sklearn import model_selection, neighbors
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x,y,test_size=0.1)
#Splitting Training and Test Set
#Since we have a very small dataset, we will train our model with all availabe data.

from sklearn.tree import DecisionTreeRegressor
regressor = DecisionTreeRegressor(random_state=0)

#Fitting model with trainig data
regressor.fit(x, y)

# Saving model to disk
pickle.dump(regressor, open('model.pkl','wb'))

# Loading model to compare the results
model = pickle.load(open('model.pkl','rb'))
print(model.predict([[1,1,517,515,2,830,819]]))